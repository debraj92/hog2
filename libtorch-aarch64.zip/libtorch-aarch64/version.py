__version__ = '1.11.0a0+git91af74c'
debug = False
cuda = None
git_version = '91af74c934384b9170555ca593729f82c07ffcfa'
hip = None
