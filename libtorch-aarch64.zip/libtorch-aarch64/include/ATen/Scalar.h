#pragma once

#include <ATen/core/Scalar.h>
